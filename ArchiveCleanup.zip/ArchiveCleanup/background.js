chrome.runtime.onInstalled.addListener(() => {
    console.log('Backup Manager Archive Cleanup extension installed.');
});

